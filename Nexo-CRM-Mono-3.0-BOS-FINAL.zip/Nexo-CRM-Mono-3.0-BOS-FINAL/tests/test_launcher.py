"""Iniciador real em subprocesso, sem instalar pacotes nem abrir navegador."""
from pathlib import Path
import os,sys,subprocess,time,signal,json,sqlite3
import httpx
ROOT=Path(__file__).resolve().parents[1]

def test_launcher_http_setup_and_automatic_backup(tmp_path):
    env=os.environ.copy();env.update(NEXO_DATA_DIR=str(tmp_path),NEXO_ORIGIN='http://127.0.0.1:8879')
    env.pop('DATABASE_URL',None);env.pop('NEXO_ENV',None);env.pop('NEXO_SETUP_TOKEN',None)
    with (tmp_path/'launcher.log').open('w') as log:
        p=subprocess.Popen([sys.executable,'iniciar.py','--no-install','--no-browser','--port','8879'],cwd=ROOT,env=env,stdout=log,stderr=log)
        try:
            for _ in range(100):
                try:
                    r=httpx.get('http://127.0.0.1:8879/api/health',timeout=1)
                    if r.status_code==200:break
                except httpx.RequestError:pass
                if p.poll() is not None:raise AssertionError((tmp_path/'launcher.log').read_text())
                time.sleep(.1)
            else:raise AssertionError('Iniciador não respondeu')
            assert (tmp_path/'server.pid').exists()
            for _ in range(50):
                if list((tmp_path/'backups').glob('conjunto-*.manifest.json')):break
                time.sleep(.1)
            assert len(list((tmp_path/'backups').glob('integral-*.sqlite')))==1
            token=(tmp_path/'setup-token.txt').read_text().strip();assert len(token)>=24
            with httpx.Client(base_url='http://127.0.0.1:8879',headers={'Origin':'http://127.0.0.1:8879'}) as client:
                r=client.post('/api/setup',json={'token':token,'name':'Teste do iniciador','company':'Empresa fictícia','email':'launcher@example.com','password':'Frase exclusiva de teste 123!'})
                assert r.status_code==200,r.text
                assert client.get('/api/state').status_code==200
        finally:
            p.send_signal(signal.SIGINT)
            try:p.wait(timeout=15)
            except subprocess.TimeoutExpired:p.kill();p.wait()
        assert not (tmp_path/'server.pid').exists()
