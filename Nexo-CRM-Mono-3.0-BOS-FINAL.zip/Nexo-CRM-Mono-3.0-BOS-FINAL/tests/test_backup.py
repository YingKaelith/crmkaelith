"""Backup integral SQLite, restauração, retenção e segurança dos arquivos."""
import json,sqlite3,stat
from pathlib import Path
import pytest
from sqlalchemy import select,func
from server.backup import take_backup,restore_sqlite,checksum,business_snapshot
from server.database import users,audit,sessions
from conftest import make_record,up,tx,data


def test_backup_json_and_full_db(env):
    a=env['admin'];cl=make_record('clients');assert tx(a,[up('clients',cl)]).status_code==200
    result=take_backup(env['app'].state.config)
    assert result['full'] is True and len(result['files'])==2
    files=[env['dir']/'backups'/r['name'] for r in result['files']]
    business=json.loads(files[0].read_text());assert business['clients'][0]['id']==cl['id']
    for file,item in zip(files,result['files']):
        assert checksum(file)==item['sha256'] and file.stat().st_size==item['bytes']
        assert file.stat().st_mode & 0o077==0
    with sqlite3.connect(files[1]) as conn:
        assert conn.execute('PRAGMA integrity_check').fetchone()==('ok',)
        assert conn.execute('SELECT count(*) FROM users').fetchone()==(1,)
        assert conn.execute('SELECT count(*) FROM sessions').fetchone()==(0,)
        assert conn.execute('SELECT count(*) FROM records').fetchone()==(1,)


def test_business_only_backup(env):
    result=take_backup(env['app'].state.config,full=False)
    assert not result['full'] and len(result['files'])==1


def test_backup_retention_preserves_recovery_files(env):
    recovery=env['dir']/'backups'/'antes-restauracao-manual.json';recovery.parent.mkdir(exist_ok=True);recovery.write_text('{}')
    for _ in range(4):take_backup(env['app'].state.config,retention=2)
    assert len(list(recovery.parent.glob('conjunto-*.manifest.json')))==2
    assert len(list(recovery.parent.glob('automatico-*.json')))==2
    assert len(list(recovery.parent.glob('integral-*.sqlite')))==2
    assert recovery.exists()


def test_offline_full_restore_revokes_sessions_and_preserves_accounts(env):
    c=env['app'].state.config;a=env['admin'];cl=make_record('clients')
    assert tx(a,[up('clients',cl)]).status_code==200
    result=take_backup(c);full=env['dir']/'backups'/result['files'][1]['name']
    other=make_record('clients');assert tx(a,[up('clients',other)]).status_code==200
    a.close();env['app'].state.engine.dispose()
    recovery=restore_sqlite(c,full,'RESTAURAR');assert recovery.exists()
    with sqlite3.connect(env['dir']/'test.db') as conn:
        assert conn.execute('SELECT count(*) FROM users').fetchone()==(1,)
        assert conn.execute('SELECT count(*) FROM records').fetchone()==(1,)
        assert conn.execute('SELECT count(*) FROM sessions').fetchone()==(0,)
        assert conn.execute('SELECT action FROM audit_log ORDER BY id DESC LIMIT 1').fetchone()==('full_backup_restored',)


def test_restore_requires_explicit_confirmation_and_stopped_server(env):
    c=env['app'].state.config
    with pytest.raises(ValueError,match='Confirme'):restore_sqlite(c,Path('missing'),'')
    (env['dir']/'server.pid').write_text('12345')
    with pytest.raises(RuntimeError,match='Pare'):restore_sqlite(c,Path('missing'),'RESTAURAR')


def test_restore_rejects_non_crm_database(env):
    c=env['app'].state.config;env['app'].state.engine.dispose();f=env['dir']/'other.db'
    with sqlite3.connect(f) as conn:conn.execute('CREATE TABLE other (id INTEGER)')
    with pytest.raises(ValueError,match='não é um backup'):restore_sqlite(c,f,'RESTAURAR')


def test_failed_backup_does_not_publish_manifest(env,monkeypatch):
    import server.backup as b
    def failure(_):raise OSError('Teste de disco indisponível')
    monkeypatch.setattr(b,'business_snapshot',failure)
    with pytest.raises(OSError):take_backup(env['app'].state.config)
    assert not list((env['dir']/'backups').glob('*.manifest.json'))


def test_minimum_backup_retention(env):
    with pytest.raises(ValueError):take_backup(env['app'].state.config,retention=1)


def test_console_recovery_issues_audited_one_use_token(env):
    from server.admin import issue_reset
    from conftest import PASSWORD,ORIGIN
    from fastapi.testclient import TestClient
    url=issue_reset(env['app'].state.config,'admin@example.com');token=url.split('ativar=')[1]
    c=TestClient(env['app'],base_url=ORIGIN,headers={'Origin':ORIGIN})
    assert c.post('/api/password/reset',json={'token':token,'password':PASSWORD+' nova'}).status_code==200
    assert env['admin'].get('/api/state').status_code==401
    assert c.post('/api/password/reset',json={'token':token,'password':PASSWORD+' nova'}).status_code==400
    with env['app'].state.engine.connect() as conn:
        assert conn.execute(select(audit.c.action).where(audit.c.action=='console_password_reset_issued')).first()
