"""API regression suite. All company data and credentials are fictitious.
Each test uses its own temporary database, never the deployed database.
"""
from concurrent.futures import ThreadPoolExecutor
from copy import deepcopy
from datetime import date,timedelta
import hashlib,json,secrets,time
from fastapi.testclient import TestClient
from sqlalchemy import select,update,insert
import pytest
from server import domain as D
from server.database import users,sessions,resets,records,audit,workspace
from conftest import ORIGIN,PASSWORD,TOKEN,make_record,up,tx,data,new_role


def seed(env):
    a=env['admin'];cl=make_record('clients');deal=make_record('deals',clientId=cl['id']);p=make_record('projects',clientId=cl['id'],dealId=deal['id']);t=make_record('tasks',clientId=cl['id'],projectId=p['id']);c=make_record('contracts',clientId=cl['id']);e=make_record('entries',clientId=cl['id'],projectId=p['id'])
    result=tx(a,[up('clients',cl),up('deals',deal),up('projects',p),up('tasks',t),up('contracts',c),up('entries',e)])
    assert result.status_code==200,result.text
    return data(a)


def test_setup_and_secure_cookie_headers(env):
    a=env['admin'];assert a.get('/api/bootstrap').json()['setupRequired'] is False
    r=a.post('/api/login',json={'email':'admin@example.com','password':PASSWORD})
    cookie=r.headers['set-cookie'].lower();assert 'httponly' in cookie and 'samesite=strict' in cookie and 'path=/' in cookie
    assert 'unsafe-inline' not in r.headers['content-security-policy'].split('script-src')[1].split(';')[0]
    assert r.headers['cache-control']=='no-store'
    assert r.headers['x-frame-options']=='DENY'
    assert 'password_hash' not in r.text


def test_setup_cannot_be_reused(env):
    r=env['admin'].post('/api/setup',json={'token':TOKEN,'email':'other@example.com','name':'Outro','company':'Outra','password':PASSWORD})
    assert r.status_code==409


def test_unauthenticated_cannot_access_any_data(env):
    client=TestClient(env['app'],base_url=ORIGIN)
    for path in ['/api/state','/api/session','/api/backup','/api/users','/api/audit','/api/admin/status']:
        assert client.get(path).status_code==401,path


def test_wrong_origin_and_missing_csrf_blocked(env):
    a=env['admin'];r=a.post('/api/logout',headers={'Origin':'https://evil.example','X-CSRF-Token':'wrong'},json={});assert r.status_code==403
    a.headers.pop('X-CSRF-Token');assert tx(a,[up('clients',make_record('clients'))]).status_code==403
    assert data(a)['clients']==[]


def test_login_uses_generic_error_and_no_password_echo(env):
    a=env['admin'];r1=a.post('/api/login',json={'email':'admin@example.com','password':'wrong'});r2=a.post('/api/login',json={'email':'nobody@example.com','password':'wrong'})
    assert r1.status_code==r2.status_code==401 and r1.json()==r2.json()


def test_password_is_argon2id_not_plaintext(env):
    with env['app'].state.engine.connect() as c:row=c.execute(select(users)).mappings().first()
    assert row['password_hash'].startswith('$argon2id$') and PASSWORD not in row['password_hash']


def test_client_persisted_between_independent_sessions(env):
    client=make_record('clients',name='Cliente compartilhado');assert tx(env['admin'],[up('clients',client)]).status_code==200
    second,user=new_role(env,'operations')
    assert data(second)['clients'][0]['name']=='Cliente compartilhado'
    assert second.cookies.get('nexo_session')!=env['admin'].cookies.get('nexo_session')


def test_allowed_create_update_and_server_timestamps(env):
    a=env['admin'];cl=make_record('clients');cl['createdAt']='2000-01-01T00:00:00Z'
    r=tx(a,[up('clients',cl)]);assert r.status_code==200
    row=data(a)['clients'][0];assert row['createdAt']!='2000-01-01T00:00:00Z'
    oldcreated=row['createdAt'];row['name']='Alterado';row['createdAt']='1999-01-01T00:00:00Z'
    assert tx(a,[up('clients',row)]).status_code==200
    got=data(a)['clients'][0];assert got['name']=='Alterado' and got['createdAt']==oldcreated


def test_atomic_rollback_on_invalid_child(env):
    a=env['admin'];cl=make_record('clients');deal=make_record('deals',clientId='missing')
    before=data(a)['meta']['revision']
    assert tx(a,[up('clients',cl),up('deals',deal)]).status_code==422
    assert data(a)['clients']==[] and data(a)['meta']['revision']==before


@pytest.mark.parametrize('kind,field,value',[
 ('clients','name',''),('clients','email','invalid-email'),('clients','website','javascript:alert(1)'),
 ('deals','nextAction',''),('deals','valueCents',1.25),('deals','valueCents',True),('deals','stage','unknown'),
 ('projects','dueDate','2026-02-30'),('tasks','spentHours',-2),('contracts','dueDay',32),('entries','valueCents',0),
])
def test_invalid_fields_rejected_on_server(env,kind,field,value):
    a=env['admin'];cl=make_record('clients');assert tx(a,[up('clients',cl)]).status_code==200
    obj=make_record(kind,**({'clientId':cl['id']} if kind!='clients' else {}));obj[field]=value
    assert tx(a,[up(kind,obj)]).status_code==422


def test_lost_deal_needs_reason(env):
    a=env['admin'];cl=make_record('clients');deal=make_record('deals',clientId=cl['id'],stage='lost',closedAt=D.today())
    assert tx(a,[up('clients',cl),up('deals',deal)]).status_code==422


def test_future_payment_rejected_without_partial_write(env):
    a=env['admin'];e=make_record('entries',status='paid',paidDate=(date.fromisoformat(D.today())+timedelta(days=1)).isoformat())
    assert tx(a,[up('entries',e)]).status_code==422
    assert data(a)['entries']==[]


def test_same_record_optimistic_conflict(env):
    a=env['admin'];cl=make_record('clients');tx(a,[up('clients',cl)]);original=data(a)['clients'][0]
    one=deepcopy(original);one['name']='Primeira';two=deepcopy(original);two['name']='Segunda'
    assert tx(a,[up('clients',one)]).status_code==200
    assert tx(a,[up('clients',two)]).status_code==409
    assert data(a)['clients'][0]['name']=='Primeira'


def test_distinct_records_do_not_have_false_conflicts(env):
    a=env['admin'];c1=make_record('clients',name='A');c2=make_record('clients',name='B');tx(a,[up('clients',c1),up('clients',c2)])
    original=data(a)['clients'];one,two=original;one['name']='A novo';two['name']='B novo'
    assert tx(a,[up('clients',one)]).status_code==200
    assert tx(a,[up('clients',two)]).status_code==200


def test_concurrent_sessions_only_one_wins_same_record(env):
    a=env['admin'];tx(a,[up('clients',make_record('clients'))]);original=data(a)['clients'][0]
    clients=[]
    for i in range(2):
        c=TestClient(env['app'],base_url=ORIGIN,headers={'Origin':ORIGIN})
        r=c.post('/api/login',json={'email':'admin@example.com','password':PASSWORD});c.headers['X-CSRF-Token']=r.json()['csrf'];clients.append(c)
    def run(pair):
        i,c=pair;row=deepcopy(original);row['name']='Concorrente '+str(i);return tx(c,[up('clients',row)]).status_code
    with ThreadPoolExecutor(2) as pool:results=list(pool.map(run,enumerate(clients)))
    assert sorted(results)==[200,409]


def test_idempotency_replay_does_not_duplicate(env):
    a=env['admin'];payload={'requestId':secrets.token_hex(12),'upserts':[up('clients',make_record('clients'))],'deletes':[]}
    r1=a.post('/api/transactions',json=payload);r2=a.post('/api/transactions',json=payload)
    assert r1.status_code==r2.status_code==200 and r2.json()['replayed'] is True
    assert len(data(a)['clients'])==1
    payload['upserts'][0]['record']['name']='Alterado';assert a.post('/api/transactions',json=payload).status_code==409


def test_delete_referenced_client_blocked(env):
    d=seed(env);a=env['admin'];r=d['clients'][0]
    assert tx(a,deletes=[{'kind':'clients','id':r['id'],'expectedRevision':r['_rev']}]).status_code==422
    assert len(data(a)['clients'])==1


def test_cross_client_relation_rejected(env):
    a=env['admin'];c1=make_record('clients');c2=make_record('clients');deal=make_record('deals',clientId=c1['id']);p=make_record('projects',clientId=c2['id'],dealId=deal['id'])
    assert tx(a,[up('clients',c1),up('clients',c2),up('deals',deal),up('projects',p)]).status_code==422


def test_accept_proposal_requires_atomic_sale_transition(env):
    a=env['admin'];c=make_record('clients');deal=make_record('deals',clientId=c['id']);p=make_record('proposals',clientId=c['id'],dealId=deal['id'],status='accepted')
    assert tx(a,[up('clients',c),up('deals',deal),up('proposals',p)]).status_code==422
    c['status']='active';deal['stage']='won';deal['closedAt']=D.today()
    assert tx(a,[up('clients',c),up('deals',deal),up('proposals',p)]).status_code==200
    assert len(data(a)['entries'])==0 # accepted != received


def test_discount_and_proposal_code_rules(env):
    a=env['admin'];c=make_record('clients');p=make_record('proposals',clientId=c['id'],discountCents=200000)
    assert tx(a,[up('clients',c),up('proposals',p)]).status_code==422
    p['discountCents']=0;p2=make_record('proposals',clientId=c['id'],code=p['code'])
    assert tx(a,[up('clients',c),up('proposals',p),up('proposals',p2)]).status_code==422


def test_recurring_duplicate_and_link_lock(env):
    a=env['admin'];c=make_record('clients');contract=make_record('contracts',clientId=c['id']);e=make_record('entries',clientId=c['id'],contractId=contract['id'])
    assert tx(a,[up('clients',c),up('contracts',contract),up('entries',e)]).status_code==200
    duplicate=deepcopy(e);duplicate['id']=secrets.token_hex(12)
    assert tx(a,[up('entries',duplicate)]).status_code==422
    saved=data(a)['entries'][0];saved['contractId']=''
    assert tx(a,[up('entries',saved)]).status_code==422


@pytest.mark.parametrize('role,blocked',[('sales','entries'),('operations','deals'),('finance','proposals'),('operations','clients'),('finance','tasks')])
def test_role_write_boundaries(env,role,blocked):
    seed(env);account,_=new_role(env,role)
    assert tx(account,[up(blocked,make_record(blocked))]).status_code==403


def test_hidden_modules_not_returned_by_api(env):
    seed(env)
    for role,hidden in [('sales',['entries','contracts']),('operations',['entries','contracts','deals','proposals']),('finance',['deals','proposals','tasks'])]:
        account,_=new_role(env,role);d=data(account)
        for kind in hidden:assert d[kind]==[],(role,kind)
        for endpoint in ['/api/backup','/api/users','/api/audit','/api/admin/status']:
            assert account.get(endpoint).status_code==403,(role,endpoint)


def test_operations_budget_redaction_and_preservation(env):
    seed(env);op,_=new_role(env,'operations');d=data(op);p=d['projects'][0]
    assert p['budgetCents']==0 and p['dealId']==''
    p['title']='Prazo revisado';assert tx(op,[up('projects',p)]).status_code==200
    assert data(env['admin'])['projects'][0]['budgetCents']==100000
    p=data(op)['projects'][0];p['budgetCents']=500
    assert tx(op,[up('projects',p)]).status_code==403


def test_finance_can_write_ledger_not_clients(env):
    seed(env);account,_=new_role(env,'finance');d=data(account)
    e=d['entries'][0];e['status']='paid';e['paidDate']=D.today()
    assert tx(account,[up('entries',e)]).status_code==200
    assert data(env['admin'])['entries'][0]['status']=='paid'


def test_activity_financial_visibility_and_idor(env):
    seed(env);a=env['admin'];cl=data(a)['clients'][0]
    financial=make_record('activities',clientId=cl['id'],text='Recebido R$ 1.000,00',visibility='finance')
    shared=make_record('activities',clientId=cl['id'],text='Reunião de briefing',visibility='shared')
    assert tx(a,[up('activities',financial),up('activities',shared)]).status_code==200
    op,_=new_role(env,'operations');assert len(data(op)['activities'])==1
    private=next(r for r in data(a)['activities'] if r['visibility']=='finance');private['text']='tentativa'
    assert tx(op,[up('activities',private)]).status_code==403


def test_admin_audit_records_actor_and_fields(env):
    a=env['admin'];r=make_record('clients');tx(a,[up('clients',r)])
    row=next(x for x in a.get('/api/audit').json()['events'] if x['action']=='record_created')
    assert row['actor']=='admin@example.com' and row['record_id']==r['id'] and 'name' in row['details']['fields']
    assert PASSWORD not in json.dumps(a.get('/api/audit').json())


def test_last_admin_guard(env):
    a=env['admin'];uid=env['user']['id']
    assert a.patch('/api/users/'+uid,json={'active':False}).status_code==409
    assert a.patch('/api/users/'+uid,json={'role':'operations'}).status_code==409


def test_disable_user_revokes_existing_sessions(env):
    account,user=new_role(env,'sales');assert account.get('/api/state').status_code==200
    assert env['admin'].patch('/api/users/'+user['id'],json={'active':False}).status_code==200
    assert account.get('/api/state').status_code==401
    assert account.post('/api/login',json={'email':user['email'],'password':PASSWORD}).status_code==401


def test_role_change_revokes_sessions_immediately(env):
    account,user=new_role(env,'sales')
    assert env['admin'].patch('/api/users/'+user['id'],json={'role':'operations'}).status_code==200
    assert account.get('/api/state').status_code==401


def test_reset_token_one_time_and_new_password(env):
    account,user=new_role(env,'sales');a=env['admin']
    token=a.post('/api/users/'+user['id']+'/reset',json={}).json()['activationToken']
    new_password='Outra senha exclusiva de teste!'
    assert account.post('/api/password/reset',json={'token':token,'password':new_password}).status_code==200
    assert account.post('/api/password/reset',json={'token':token,'password':new_password}).status_code==400
    assert account.get('/api/state').status_code==401
    assert account.post('/api/login',json={'email':user['email'],'password':new_password}).status_code==200


def test_expired_reset_token_rejected(env):
    a=env['admin'];_,user=new_role(env,'sales')
    token=a.post('/api/users/'+user['id']+'/reset',json={}).json()['activationToken']
    with env['app'].state.engine.begin() as c:c.execute(update(resets).values(expires=int(time.time())-10))
    assert a.post('/api/password/reset',json={'token':token,'password':PASSWORD}).status_code==400


def test_change_password_rotates_current_session_revokes_others(env):
    a=env['admin'];second=TestClient(env['app'],base_url=ORIGIN,headers={'Origin':ORIGIN})
    r=second.post('/api/login',json={'email':'admin@example.com','password':PASSWORD});assert r.status_code==200
    oldtoken=a.cookies.get('nexo_session')
    response=a.post('/api/password/change',json={'current':PASSWORD,'password':'Frase alterada para testar a rotação!'})
    assert response.status_code==200 and oldtoken!=a.cookies.get('nexo_session')
    assert second.get('/api/state').status_code==401 and a.get('/api/state').status_code==200


def test_logout_invalidates_server_session(env):
    a=env['admin'];token=a.cookies.get('nexo_session')
    assert a.post('/api/logout',json={}).status_code==200
    a.cookies.set('nexo_session',token,domain='testserver.local',path='/')
    assert a.get('/api/state').status_code==401


def test_absolute_and_idle_session_expiry(env):
    a=env['admin']
    with env['app'].state.engine.begin() as c:c.execute(update(sessions).values(last_seen=int(time.time())-3*3600))
    assert a.get('/api/state').status_code==401


def test_rate_limit_survives_clients(env):
    a=env['admin']
    codes=[a.post('/api/login',json={'email':'absent@example.com','password':'bad'}).status_code for _ in range(13)]
    assert codes[-1]==429 and 401 in codes


def test_backup_excludes_auth_and_restores_business_links(env):
    original=seed(env);a=env['admin'];backup=a.get('/api/backup').json()
    assert 'users' not in backup and 'password_hash' not in json.dumps(backup)
    preview=a.post('/api/import/preview',json={'data':backup});assert preview.status_code==200
    result=a.post('/api/import',json={'data':backup,'confirmation':'RESTAURAR','expectedRevision':preview.json()['revision']})
    assert result.status_code==200,result.text
    restored=data(a);assert restored['tasks'][0]['projectId']==original['projects'][0]['id']
    assert a.get('/api/users').status_code==200
    assert list((env['dir']/'backups').glob('antes-restauracao-*.json'))


def test_import_legacy_visibility_conservative(env):
    seed(env);a=env['admin'];backup=a.get('/api/backup').json();backup['version']='1.0.0'
    backup['activities']=[make_record('activities',clientId=backup['clients'][0]['id'],text='Recebido R$ 5.000')]
    before=data(a)['meta']['revision']
    response=a.post('/api/import',json={'data':backup,'confirmation':'RESTAURAR','expectedRevision':before})
    assert response.status_code==200,response.text
    assert data(a)['activities'][0]['visibility']=='private'
    op,_=new_role(env,'operations');assert data(op)['activities']==[]


def test_restore_detects_change_after_preview(env):
    a=env['admin'];backup=a.get('/api/backup').json();preview=a.post('/api/import/preview',json={'data':backup}).json()
    tx(a,[up('clients',make_record('clients'))])
    result=a.post('/api/import',json={'data':backup,'confirmation':'RESTAURAR','expectedRevision':preview['revision']})
    assert result.status_code==409 and len(data(a)['clients'])==1


def test_invalid_import_does_not_replace(env):
    seed(env);a=env['admin'];backup=a.get('/api/backup').json();backup['clients']=[]
    result=a.post('/api/import',json={'data':backup,'confirmation':'RESTAURAR','expectedRevision':data(a)['meta']['revision']})
    assert result.status_code==422 and len(data(a)['clients'])==1


def test_settings_revision_conflict(env):
    a=env['admin'];d=data(a);s=d['settings'];s['company']='Novo nome'
    assert tx(a,settings=s,settingsRevision=d['meta'].get('settingsRevision',0)).status_code==200
    assert tx(a,settings=s,settingsRevision=d['meta'].get('settingsRevision',0)).status_code==409


def test_unknown_and_polluting_properties_rejected(env):
    a=env['admin'];r=make_record('clients');r['isAdmin']=True
    assert tx(a,[up('clients',r)]).status_code==422
    r.pop('isAdmin');r['__proto__']={'admin':True}
    assert tx(a,[up('clients',r)]).status_code==422


def test_static_allowlist_and_host_check(env):
    a=env['admin']
    for path in ['/assets/../../../server/app.py','/assets/server.py','/data/nexo.db','/.env','/api/docs','/openapi.json']:
        assert a.get(path).status_code in (404,400),path
    assert a.get('/api/health',headers={'Host':'evil.example'}).status_code==400


def test_request_size_limit(env):
    a=env['admin'];r=a.post('/api/login',content='{}',headers={'Content-Type':'application/json','Content-Length':str(17*1024*1024)})
    assert r.status_code==413
