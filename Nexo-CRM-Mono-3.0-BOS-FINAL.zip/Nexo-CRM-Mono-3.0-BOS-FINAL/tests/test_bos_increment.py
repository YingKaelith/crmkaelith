"""Regression tests for the first Business Operating System increment.
All records are fictitious and use a temporary database fixture.
"""
from copy import deepcopy

from conftest import make_record, up, tx, data
from server import domain as D


def seed_project(env, title='Projeto BOS'):
    a=env['admin']
    client=make_record('clients', name='Cliente BOS')
    project=make_record('projects', clientId=client['id'], title=title)
    assert tx(a,[up('clients',client),up('projects',project)]).status_code==200
    return client,project


def test_operational_fields_persist_without_parallel_entities(env):
    a=env['admin']
    client=make_record('clients',health='attention',nextAction='Aprovar planejamento',nextDate=D.today())
    project=make_record('projects',clientId=client['id'],priority='high',nextAction='Finalizar estratégia')
    task=make_record('tasks',clientId=client['id'],projectId=project['id'],status='doing',progress=45,nextAction='Enviar primeira versão',approver='Admin de testes',participants=['Admin de testes'])
    result=tx(a,[up('clients',client),up('projects',project),up('tasks',task)])
    assert result.status_code==200,result.text
    state=data(a)
    assert state['clients'][0]['health']=='attention'
    assert state['clients'][0]['nextAction']=='Aprovar planejamento'
    assert state['projects'][0]['priority']=='high'
    assert state['projects'][0]['nextAction']=='Finalizar estratégia'
    saved=state['tasks'][0]
    assert saved['progress']==45 and saved['approver']=='Admin de testes'
    assert saved['participants']==['Admin de testes']


def test_task_dependency_is_validated_and_persisted(env):
    a=env['admin'];client,project=seed_project(env)
    first=make_record('tasks',clientId=client['id'],projectId=project['id'],title='Estratégia')
    second=make_record('tasks',clientId=client['id'],projectId=project['id'],title='Criativos',dependsOn=[first['id']])
    result=tx(a,[up('tasks',first),up('tasks',second)])
    assert result.status_code==200,result.text
    saved={t['title']:t for t in data(a)['tasks']}
    assert saved['Criativos']['dependsOn']==[first['id']]


def test_missing_or_cross_project_dependency_is_rejected(env):
    a=env['admin'];client,project=seed_project(env)
    bad=make_record('tasks',clientId=client['id'],projectId=project['id'],dependsOn=['f'*24])
    assert tx(a,[up('tasks',bad)]).status_code==422

    other=make_record('projects',clientId=client['id'],title='Outro projeto')
    first=make_record('tasks',clientId=client['id'],projectId=project['id'],title='Origem')
    cross=make_record('tasks',clientId=client['id'],projectId=other['id'],title='Destino',dependsOn=[first['id']])
    assert tx(a,[up('projects',other),up('tasks',first),up('tasks',cross)]).status_code==422


def test_dependency_cycle_is_rejected_atomically(env):
    a=env['admin'];client,project=seed_project(env)
    first=make_record('tasks',clientId=client['id'],projectId=project['id'],title='Primeira')
    second=make_record('tasks',clientId=client['id'],projectId=project['id'],title='Segunda',dependsOn=[first['id']])
    assert tx(a,[up('tasks',first),up('tasks',second)]).status_code==200
    state=data(a);saved={t['title']:t for t in state['tasks']}
    changed=deepcopy(saved['Primeira']);changed['dependsOn']=[saved['Segunda']['id']]
    before_revision=state['meta']['revision']
    result=tx(a,[up('tasks',changed)])
    assert result.status_code==422
    after=data(a)
    assert after['meta']['revision']==before_revision
    persisted={t['title']:t for t in after['tasks']}
    assert persisted['Primeira'].get('dependsOn',[])==[]


def test_blocked_task_requires_reason_and_unlock_source(env):
    a=env['admin'];client,project=seed_project(env)
    task=make_record('tasks',clientId=client['id'],projectId=project['id'],status='blocked')
    assert tx(a,[up('tasks',task)]).status_code==422
    task['blockedReason']='Aguardando acesso'
    assert tx(a,[up('tasks',task)]).status_code==422
    task['blockedBy']='Cliente'
    task['blockedSince']=D.today()
    result=tx(a,[up('tasks',task)])
    assert result.status_code==200,result.text


def test_dependency_cycle_rejects_self_reference(env):
    a=env['admin'];client,project=seed_project(env)
    task=make_record('tasks',clientId=client['id'],projectId=project['id'])
    task['dependsOn']=[task['id']]
    assert tx(a,[up('tasks',task)]).status_code==422
