"""Mono/PWA resource contracts and hosting configuration, no provider account used."""
import json
from pathlib import Path
import struct
import pytest
from fastapi.testclient import TestClient
from server.app import Config, create_app
from server.run import server_port

ROOT = Path(__file__).resolve().parents[1]

@pytest.fixture
def public_app(tmp_path):
    app = create_app(Config('sqlite:///' + str(tmp_path/'public.db'),
                            'http://testserver', 'test-setup-token-for-mono-only', False, tmp_path))
    with TestClient(app, base_url='http://testserver') as client:
        yield client
    app.state.engine.dispose()

@pytest.mark.parametrize('url,content_type',[
    ('/', 'text/html'), ('/offline.html','text/html'),
    ('/manifest.webmanifest','application/manifest+json'),
    ('/sw.js','application/javascript'), ('/assets/pwa.js','application/javascript'),
    ('/assets/styles.css','text/css'), ('/robots.txt','text/plain'),
    ('/icons/icon-192.png','image/png'), ('/icons/icon-512.png','image/png'),
    ('/icons/maskable-512.png','image/png'), ('/icons/apple-touch-icon.png','image/png'),
    ('/icons/favicon-32.png','image/png')
])
def test_public_resource_contract(public_app,url,content_type):
    r = public_app.get(url)
    assert r.status_code == 200
    assert r.headers['content-type'].startswith(content_type)
    assert r.headers['cache-control'] == 'no-store'
    assert "worker-src 'self'" in r.headers['content-security-policy']
    assert r.headers['x-content-type-options'] == 'nosniff'

def test_manifest_links_and_icon_dimensions(public_app):
    m=public_app.get('/manifest.webmanifest').json()
    assert m['display']=='standalone' and m['start_url']=='/' and m['scope']=='/'
    assert m['theme_color']=='#111111' and m['background_color']=='#ffffff'
    assert not m['prefer_related_applications']
    for icon in m['icons']:
        content=public_app.get(icon['src']).content
        assert content[:8]==b'\x89PNG\r\n\x1a\n'
        w,h=struct.unpack('>II',content[16:24])
        assert icon['sizes']==f'{w}x{h}'
    assert {'192x192','512x512'} <= {i['sizes'] for i in m['icons']}

def test_worker_scope_and_protected_data(public_app):
    assert public_app.get('/sw.js').headers['service-worker-allowed']=='/'
    assert public_app.get('/api/state').status_code==401
    assert public_app.get('/api/backup').status_code==401
    assert public_app.get('/api/users').status_code==401
    for path in ['/icons/not-present.png','/assets/secret.txt','/data/setup-token.txt']:
        assert public_app.get(path).status_code==404

def test_manifest_in_html_and_brand_remains_monochrome(public_app):
    html=public_app.get('/').text
    assert 'rel="manifest"' in html and '/assets/pwa.js' in html
    assert "setProperty('--primary','#111111')" in public_app.get('/assets/app.js').text
    assert "setProperty('--primary',db.settings.brandColor)" not in public_app.get('/assets/app.js').text
    assert 'filter:grayscale' not in public_app.get('/assets/styles.css').text

@pytest.fixture
def config_env(tmp_path,monkeypatch):
    for key in ['DATABASE_URL','NEXO_ORIGIN','RENDER_EXTERNAL_URL','NEXO_ENV','NEXO_BACKUP_MODE']:
        monkeypatch.delenv(key,raising=False)
    monkeypatch.setenv('NEXO_DATA_DIR',str(tmp_path))
    monkeypatch.setenv('NEXO_SETUP_TOKEN','a-unique-setup-token-used-only-in-tests')
    return monkeypatch

def test_render_origin_is_derived_from_runtime_not_from_request(config_env):
    config_env.setenv('RENDER_EXTERNAL_URL','https://nexo-example.onrender.com')
    config_env.setenv('NEXO_ENV','production')
    config_env.setenv('DATABASE_URL','postgresql://example:example@db/nexo')
    c=Config.environment()
    assert c.public_origin=='https://nexo-example.onrender.com'
    assert c.production

def test_custom_domain_has_explicit_precedence(config_env):
    config_env.setenv('RENDER_EXTERNAL_URL','https://nexo-example.onrender.com')
    config_env.setenv('NEXO_ORIGIN','https://crm.company.example/')
    assert Config.environment().public_origin=='https://crm.company.example'

@pytest.mark.parametrize('origin',[
    'https://crm.example/path','https://crm.example?token=x','https://a:b@crm.example',
    'https://crm.example#x','javascript:alert(1)','crm.example'
])
def test_reject_noncanonical_origin(config_env,origin):
    config_env.setenv('NEXO_ORIGIN',origin)
    with pytest.raises(RuntimeError):Config.environment()

@pytest.mark.parametrize('url',['sqlite:///test.db','mysql://user:pass@db/crm'])
def test_production_refuses_wrong_database(config_env,url):
    config_env.setenv('NEXO_ENV','production');config_env.setenv('NEXO_ORIGIN','https://crm.example')
    config_env.setenv('DATABASE_URL',url)
    with pytest.raises(RuntimeError):Config.environment()

def test_production_refuses_plain_http(config_env):
    config_env.setenv('NEXO_ENV','production');config_env.setenv('NEXO_ORIGIN','http://crm.example')
    config_env.setenv('DATABASE_URL','postgresql://example:example@db/crm')
    with pytest.raises(RuntimeError):Config.environment()

def test_hosted_backup_mode_is_explicit(config_env):
    config_env.setenv('NEXO_BACKUP_MODE','managed')
    assert Config.environment().backup_mode=='managed'
    config_env.setenv('NEXO_BACKUP_MODE','unknown')
    with pytest.raises(RuntimeError):Config.environment()

@pytest.mark.parametrize('value',['abc','0','65536','-1'])
def test_host_port_validation(monkeypatch,value):
    monkeypatch.setenv('PORT',value)
    with pytest.raises(ValueError):server_port()

def test_host_port_and_default(monkeypatch):
    monkeypatch.setenv('PORT','10000');assert server_port()==10000
    monkeypatch.delenv('PORT');assert server_port()==8000
