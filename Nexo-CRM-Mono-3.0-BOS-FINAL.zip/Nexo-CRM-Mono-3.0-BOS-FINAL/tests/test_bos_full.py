import secrets
from pathlib import Path
from conftest import make_record, up, tx, data
from server import domain as D


def bos_record(kind, **overrides):
    stamp=D.now(); day=D.today()
    r=dict(id=secrets.token_hex(12),createdAt=stamp,updatedAt=stamp,title='Registro BOS',clientId='',projectId='',owner='Admin de testes',description='Contexto operacional',nextAction='Revisar',category='Operação',relatedType='',relatedId='',status='planned',priority='normal',dueDate=day,startDate=day,tags=['bos'],data={},visibility='internal')
    if kind=='time_entries': r.update(hours=1.5,date=day,status='done')
    if kind=='files': r.update(originalName='briefing.pdf',storageKey='',mimeType='application/pdf',size=0,version=1,status='active')
    r.update(overrides)
    return r


def test_all_bos_collections_exist_on_state(env):
    state=data(env['admin'])
    for kind in D.BOS_KINDS:
        assert kind in state and isinstance(state[kind], list)


def test_generic_bos_records_persist_and_link_to_same_client_project(env):
    a=env['admin']; client=make_record('clients',name='Cliente Integrado'); project=make_record('projects',clientId=client['id'])
    strategy=bos_record('strategies',title='Estratégia 2027',clientId=client['id'],projectId=project['id'])
    approval=bos_record('approvals',title='Aprovar estratégia',clientId=client['id'],projectId=project['id'],status='approval')
    campaign=bos_record('campaigns',title='Meta Ads',clientId=client['id'],projectId=project['id'],status='active',data={'platform':'meta','budgetCents':250000})
    res=tx(a,[up('clients',client),up('projects',project),up('strategies',strategy),up('approvals',approval),up('campaigns',campaign)])
    assert res.status_code==200,res.text
    state=data(a)
    assert state['strategies'][0]['projectId']==project['id']
    assert state['approvals'][0]['status']=='approval'
    assert state['campaigns'][0]['data']['platform']=='meta'


def test_generic_bos_record_rejects_cross_client_project(env):
    a=env['admin']; c1=make_record('clients',name='A'); c2=make_record('clients',name='B'); project=make_record('projects',clientId=c1['id'])
    record=bos_record('contents',clientId=c2['id'],projectId=project['id'])
    res=tx(a,[up('clients',c1),up('clients',c2),up('projects',project),up('contents',record)])
    assert res.status_code==422


def test_real_file_upload_is_stored_outside_database(env):
    a=env['admin']; payload=b'%PDF-1.4\nconteudo ficticio\n%%EOF\n'
    res=a.post('/api/files/upload',content=payload,headers={'content-type':'application/pdf','x-file-name':'briefing.pdf'})
    assert res.status_code==200,res.text
    files=res.json()['data']['files']; assert len(files)==1
    meta=files[0]
    assert meta['size']==len(payload) and meta['storageKey']==meta['id']
    stored=Path(env['dir'])/'uploads'/meta['id']
    assert stored.read_bytes()==payload
    down=a.get('/api/files/'+meta['id']+'/content')
    assert down.status_code==200 and down.content==payload


def test_upload_rejects_unapproved_mime(env):
    res=env['admin'].post('/api/files/upload',content=b'x',headers={'content-type':'application/x-msdownload','x-file-name':'bad.exe'})
    assert res.status_code==415


def test_client_portal_is_server_scoped_to_one_client(env):
    from fastapi.testclient import TestClient
    from conftest import ORIGIN, PASSWORD
    a=env['admin']
    c1=make_record('clients',name='Cliente Portal A');c2=make_record('clients',name='Cliente Portal B')
    p1=make_record('projects',clientId=c1['id'],title='Projeto A');p2=make_record('projects',clientId=c2['id'],title='Projeto B')
    t1=make_record('tasks',clientId=c1['id'],projectId=p1['id'],title='Entrega A');t2=make_record('tasks',clientId=c2['id'],projectId=p2['id'],title='Entrega B')
    assert tx(a,[up('clients',c1),up('clients',c2),up('projects',p1),up('projects',p2),up('tasks',t1),up('tasks',t2)]).status_code==200
    email='portal-'+secrets.token_hex(3)+'@example.com'
    made=a.post('/api/users',json={'name':'Contato Cliente','email':email,'role':'client','clientId':c1['id']})
    assert made.status_code==200,made.text
    portal=TestClient(env['app'],base_url=ORIGIN,headers={'Origin':ORIGIN})
    token=made.json()['activationToken'];assert portal.post('/api/password/reset',json={'token':token,'password':PASSWORD}).status_code==200
    logged=portal.post('/api/login',json={'email':email,'password':PASSWORD});assert logged.status_code==200,logged.text
    portal.headers['X-CSRF-Token']=logged.json()['csrf']
    state=data(portal)
    assert [c['id'] for c in state['clients']]==[c1['id']]
    assert [p['id'] for p in state['projects']]==[p1['id']]
    assert [t['id'] for t in state['tasks']]==[t1['id']]
    assert state['entries']==[] and state['deals']==[] and state['proposals']==[]
    own=bos_record('approvals',title='Aprovar criativo',clientId=c1['id'],projectId=p1['id'],status='approved',visibility='client')
    assert tx(portal,[up('approvals',own)]).status_code==200
    foreign=bos_record('approvals',title='Inválido',clientId=c2['id'],projectId=p2['id'],status='approved',visibility='client')
    assert tx(portal,[up('approvals',foreign)]).status_code==403
    portal.close()
