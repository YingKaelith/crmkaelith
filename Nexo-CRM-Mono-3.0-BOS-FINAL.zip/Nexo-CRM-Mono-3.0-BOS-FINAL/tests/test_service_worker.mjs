/* Node execution of the real SW, with explicit in-memory network/cache mocks.
   This verifies routing/privacy semantics, NOT a browser install or real TLS. */
import vm from 'node:vm';
import fs from 'node:fs';
import path from 'node:path';
import assert from 'node:assert/strict';
import {fileURLToPath} from 'node:url';
const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
const handlers={}, storage=new Map(), fetched=[], passed=[];
let online=true, skipped=0,claimed=0;
const responseFor=url=>new Response(url.includes('offline.html')?fs.readFileSync(path.join(root,'web/offline.html'),'utf8'):`public:${url}`);
const caches={
  async open(name){
    if(!storage.has(name))storage.set(name,new Map());
    const bucket=storage.get(name);
    return {
      async addAll(urls){for(const url of urls){fetched.push(url);bucket.set(url,responseFor(url));}},
      async match(url){return bucket.get(url)?.clone();}
    };
  },
  async keys(){return [...storage.keys()];},
  async delete(key){return storage.delete(key);}
};
const self={location:{origin:'https://crm.example'},
  addEventListener:(name,handler)=>handlers[name]=handler,
  clients:{claim:async()=>{claimed++;}},skipWaiting:async()=>{skipped++;}};
vm.runInNewContext(fs.readFileSync(path.join(root,'web/sw.js'),'utf8'),{
  self,caches,URL,Response,fetch:async request=>{if(!online)throw Error('offline');return responseFor(request.url||request);}
},{filename:'sw.js'});
function ok(name){passed.push(name);console.log(`PASS ${passed.length}: ${name}`);}
async function lifecycle(type){let p;handlers[type]({waitUntil:v=>p=v});await p;}
function route(pathname,method='GET',mode='cors'){
  let promise=null;handlers.fetch({request:{url:'https://crm.example'+pathname,method,mode},respondWith:v=>promise=Promise.resolve(v)});return promise;
}
await lifecycle('install');
assert.equal(skipped,0);ok('Instalação não força ativação nem recarregamento');
assert.equal(fetched.length,6);assert(fetched.every(p=>p==='/offline.html'||p.startsWith('/icons/')));ok('Cache inicial limitado a seis recursos públicos');
storage.set('nexo-public-old',new Map());storage.set('another-app-cache',new Map());
await lifecycle('activate');assert(!storage.has('nexo-public-old'));assert(storage.has('another-app-cache'));assert.equal(claimed,1);ok('Ativação limpa somente versões antigas do próprio cache');
for(const p of ['/api/state','/api/session','/api/backup','/api/users'])assert.equal(route(p),null);ok('Leituras autenticadas não são interceptadas nem armazenadas');
assert.equal(route('/api/transactions','POST'),null);assert.equal(route('/api/login','POST'),null);ok('Login e alterações não entram em fila nem em cache');
assert.equal(route('/?ativar=example-token'),null);ok('Tokens em consulta não entram no cache público');
const onlineResponse=await route('/','GET','navigate');assert((await onlineResponse.text()).includes('https://crm.example/'));ok('Navegação online vem da rede, não de cópia de dados');
online=false;const offline=await route('/','GET','navigate');assert((await offline.text()).includes('Vamos nos reconectar.'));ok('Falha de rede apresenta a tela offline genérica');
assert.equal(route('/api/state','GET','navigate'),null);ok('API navegada diretamente nunca recebe uma resposta offline fictícia');
assert.equal(await (await route('/icons/icon-192.png')).text(),'public:/icons/icon-192.png');ok('Ícone público continua disponível offline');
const cachedPaths=[...storage.get('nexo-public-v3.0.0').keys()];assert(!cachedPaths.includes('/'));assert(!cachedPaths.some(p=>p.startsWith('/api/')));ok('Navegar não adiciona documentos ou dados de usuário ao cache');
handlers.message({data:{type:'OTHER'}});assert.equal(skipped,0);handlers.message({data:{type:'ACTIVATE_UPDATE'}});assert.equal(skipped,1);ok('Atualização só é ativada mediante mensagem explícita');
const out=path.join(root,'tests/evidence/2.2/service-worker-results.json');fs.mkdirSync(path.dirname(out),{recursive:true});
fs.writeFileSync(out,JSON.stringify({scope:'Node VM com rede e CacheStorage simulados; não testa instalação no navegador',passed,failures:[]},null,2));
