# Nexo CRM Mono 3.0 · Business Operating System

Sistema operacional central para agência de marketing, criação, tráfego e tecnologia. Esta versão evolui o CRM existente de forma incremental e preserva a base, autenticação, auditoria, backup e arquitetura monolítica.

## Início rápido local

Windows: execute `Iniciar-Windows.bat`.

macOS/Linux:

```bash
./Iniciar-macOS-Linux.sh
```

Ou:

```bash
python iniciar.py
```

Abra o endereço local indicado pelo iniciador. Na primeira instalação use o token criado em `data/setup-token.txt`; depois do cadastro do administrador, trate esse token como segredo e não o compartilhe.

## O que existe na 3.0

O núcleo anterior continua disponível: clientes, oportunidades, propostas, projetos, tarefas, recorrências, financeiro, interações, Meu Dia, Cliente 360, Flow Map, equipe, auditoria, backup/importação e PWA.

O Business OS adiciona persistência real para estratégia, metas, KPIs, conteúdo, campanhas, aprovações, solicitações, handoffs, reuniões, decisões, conhecimento, SOPs, checklists, desenvolvimento, bugs, deploys, change requests, incidentes, automações, integrações, infraestrutura, arquivos, comentários, notificações e apontamento de horas.

A navegação oferece quatro perspectivas dos mesmos dados: Visão geral; Comercial & estratégia; Criação & conteúdo; Tráfego, operações & tecnologia.

## Arquivos

A Central de Arquivos aceita PDF, DOCX, XLSX, CSV, imagens, SVG, MP4, MOV, ZIP, PPTX e TXT até 16 MB nesta edição monolítica. O binário é salvo em `data/uploads`; o banco mantém metadados e relações. Downloads exigem sessão válida. Para volumes maiores, use Object Storage externo.

## Portal do cliente

O perfil `Cliente` deve ser vinculado a um cliente específico. O filtro é aplicado no backend, não apenas na interface. O portal recebe somente os registros autorizados daquele cliente e pode operar aprovações, solicitações, comentários e arquivos próprios conforme permissões.

## Segurança

- Argon2 para senhas;
- sessão HTTP-only, SameSite estrito e Secure em produção;
- CSRF/origin e Trusted Host;
- CSP, `no-store`, `nosniff`, frame deny e HSTS em produção;
- validação server-side e controle de concorrência por revisão;
- rate limiting e auditoria;
- rejeição de propriedades perigosas em JSON;
- rejeição de campos estruturados com nomes de senha/token/secret/API key/private key;
- arquivos privados fora do banco e download autenticado.

Não armazene credenciais de Meta, Google, hospedagem, banco ou APIs nos campos do CRM. Use Secret Manager/Password Manager.

## Banco e migração

SQLite é usado no modo local. Produção exige PostgreSQL e HTTPS. Os novos domínios BOS reutilizam a tabela `records`; não foram criadas entidades paralelas. O portal adiciona somente `user_scopes`, documentado em `migrations/0002_business_os_3.sql`.

Backups 2.x continuam importáveis: o servidor normaliza as novas coleções ausentes como listas vazias.

## Testes desta entrega

- 112 testes Python;
- 12 testes do service worker;
- validação de sintaxe Python/JavaScript;
- base SQLite recebida validada pelo domínio 3.0 sem regravação destrutiva;
- testes específicos de upload/download fora do banco e isolamento do portal do cliente.

Consulte `docs/RELATORIO-BOS-3.0.md` para detalhes e limites de integrações externas.

## Produção

Use `render.yaml`/`deploy/` como base para publicação. Antes do uso real, homologue HTTPS público, PostgreSQL, backups restauráveis, limites de armazenamento e monitoramento da infraestrutura escolhida.
