# Dependências e ativos

O pacote contém código-fonte do aplicativo e testes. Não redistribui interpretador
Python, navegador, imagens Docker, pacotes binários nem fontes tipográficas.
As dependências são instaladas separadamente e mantêm suas próprias licenças:
FastAPI, Starlette, Pydantic, Uvicorn, SQLAlchemy, argon2-cffi, tzdata e, no caminho
PostgreSQL, psycopg. Para testes: pytest, httpx e Playwright.

A interface utiliza a pilha de fontes do sistema e ícones SVG incorporados ao
código. As capturas contêm dados de demonstração fictícios. O nome Nexo CRM é um
nome de trabalho da entrega, sem pesquisa ou garantia de disponibilidade de marca.
A licença MIT do código não substitui as licenças das dependências ou serviços.
