#!/usr/bin/env python3
"""Iniciador individual/local. Publicação de equipe: docs/PUBLICACAO.md.
Python >= 3.11. No primeiro uso, requer internet para instalar dependências.
Não abre acesso à rede. Ctrl+C para encerrar servidor e backup automático.
"""
from __future__ import annotations
import argparse,importlib.util,os,signal,socket,subprocess,sys,time,venv,webbrowser
from pathlib import Path
ROOT=Path(__file__).resolve().parent


def dependencies(no_install:bool):
    if sys.version_info<(3,11):raise SystemExit('Instale Python 3.11 ou superior e execute novamente.')
    if no_install:
        missing=[x for x in ['fastapi','uvicorn','sqlalchemy','argon2','tzdata'] if importlib.util.find_spec(x) is None]
        if missing:raise SystemExit('Dependências ausentes: '+', '.join(missing)+'. Execute sem --no-install.')
        return
    env=ROOT/'.venv';exe=env/('Scripts/python.exe' if os.name=='nt' else 'bin/python')
    if Path(sys.prefix).resolve()!=env.resolve():
        if not exe.exists():
            print('Criando ambiente Python isolado…',flush=True);venv.EnvBuilder(with_pip=True).create(env)
        marker=env/'nexo-requirements.txt';req=(ROOT/'requirements.txt').read_text()
        if not marker.exists() or marker.read_text()!=req:
            result=subprocess.run([str(exe),'-m','pip','install','-r',str(ROOT/'requirements.txt')])
            if result.returncode:raise SystemExit('Instalação não concluída. Confira internet/permissões e execute novamente.')
            marker.write_text(req)
        raise SystemExit(subprocess.call([str(exe),str(ROOT/'iniciar.py'),'--no-install',*sys.argv[1:]]))


def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--no-install',action='store_true');p.add_argument('--no-browser',action='store_true');p.add_argument('--port',type=int,default=8765)
    a=p.parse_args();dependencies(a.no_install)
    if os.environ.get('NEXO_ENV')=='production':raise SystemExit('Para produção use o deploy documentado, não o iniciador local.')
    if not 1024<=a.port<=65535:raise SystemExit('Escolha uma porta entre 1024 e 65535.')
    host='127.0.0.1';origin=f'http://{host}:{a.port}'
    if os.environ.get('NEXO_ORIGIN',origin)!=origin:raise SystemExit('O iniciador só permite NEXO_ORIGIN igual ao endereço local impresso.')
    os.environ['NEXO_ORIGIN']=origin
    with socket.socket() as s:
        try:s.bind((host,a.port))
        except OSError:raise SystemExit('Porta em uso. Encerre outra instância ou use --port 8766.')
    import logging,threading,uvicorn
    from sqlalchemy import select,func
    from server.app import Config,create_app
    from server.database import users
    from server.backup import run_loop,restrict
    logging.basicConfig(level=logging.INFO,format='%(asctime)s %(levelname)s %(message)s')
    config=Config.environment();restrict(config.data_dir)
    pidfile=config.data_dir/'server.pid'
    if pidfile.exists():raise SystemExit('server.pid já existe. Confira se o servidor está aberto. Após uma falha, só remova esse arquivo se nenhum processo estiver usando este banco.')
    owns_pid=False
    try:
        fd=os.open(pidfile,os.O_WRONLY|os.O_CREAT|os.O_EXCL,0o600)
        owns_pid=True
        with os.fdopen(fd,'w') as f:f.write(str(os.getpid()))
        app=create_app(config)
        with app.state.engine.connect() as conn:empty=conn.execute(select(func.count()).select_from(users)).scalar_one()==0
        print('\nNEXO CRM EQUIPE 2.0\nEndereço: '+origin+'\nDados: '+str(config.data_dir)+'\nMantenha esta janela aberta. Ctrl+C encerra o servidor.\n',flush=True)
        if empty:print('Código para criar o primeiro administrador:\n'+config.setup_token+'\nNão compartilhe esse código. Não há senha padrão.\n',flush=True)
        stop=threading.Event();worker=threading.Thread(target=run_loop,args=(config,stop),daemon=True,name='nexo-backup');worker.start()
        if not a.no_browser:
            def open_when_ready():
                import urllib.request
                for _ in range(40):
                    try:
                        with urllib.request.urlopen(origin+'/api/health',timeout=1) as response:
                            if response.status==200:webbrowser.open(origin);return
                    except Exception:time.sleep(.25)
            threading.Thread(target=open_when_ready,daemon=True).start()
        try:uvicorn.run(app,host=host,port=a.port,proxy_headers=False,access_log=False)
        finally:stop.set();worker.join(timeout=15);app.state.engine.dispose()
    finally:
        if owns_pid:pidfile.unlink(missing_ok=True)

if __name__=='__main__':
    try:main()
    except KeyboardInterrupt:pass
